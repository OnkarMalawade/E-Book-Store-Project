﻿using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using System.Data.Sql;
using Microsoft.Reporting.WebForms;
using System;

namespace HomePage1
{
    public partial class WebForm23 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void Button1_Click(object sender, EventArgs e)
        {
            Getdata();
        }
        private void Getdata()
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ebookdbConnectionString"].ConnectionString);
            SqlDataAdapter da = new SqlDataAdapter("Select * from ReqDB where rqbkname ='" + TextBox1.Text + "' ", con);
            DataTable dt = new DataTable("table1");
            da.Fill(dt);
            ReportViewer1.ProcessingMode = ProcessingMode.Local;
            ReportViewer1.LocalReport.ReportPath = Server.MapPath("ReportRQ.rdlc");
            ReportViewer1.LocalReport.DataSources.Clear();
            ReportViewer1.LocalReport.DataSources.Add(new ReportDataSource("RequiementDS", dt));
            ReportViewer1.LocalReport.Refresh();
        }
}
}