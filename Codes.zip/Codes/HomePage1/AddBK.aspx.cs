﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using System.Data.Sql;
using Microsoft.Reporting.WebForms;
namespace HomePage1
{
    public partial class AddBK : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ToString());
        SqlCommand cmd;
        protected void Page_Load(object sender, EventArgs e)
        {
            con = new SqlConnection();
            con.Open();
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            String query = " Insert into BookDB(bkname,bkauthor,bkstar,pdf,audio,video,bkdesc)values('" + bkname1.Text + "','" + bkauthor2.Text + "','" + Star3.Text + "','" + TextBox1.Text + "','" + TextBox2.Text + "','" + TextBox3.Text + "','" + bkdesc3.Text + "')";
            cmd = new SqlCommand(query, con);
            cmd.ExecuteNonQuery();
            con.Close();
            Response.Redirect("AddBK.aspx");
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            bkname1.Text = string.Empty;
            bkauthor2.Text = string.Empty;
            Star3.Text = string.Empty;
            TextBox1.Text = string.Empty;
            TextBox2.Text = string.Empty;
            TextBox3.Text = string.Empty;
            bkdesc3.Text = string.Empty;
        }


    }
}