﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;


namespace HomePage1
{
    public partial class WebForm5 : System.Web.UI.Page
    {

        SqlCommand cmd = new SqlCommand();
        SqlConnection con = new SqlConnection();
        protected void Page_Load(object sender, EventArgs e)
        {
            con.ConnectionString = "Data Source=LAPTOP-6O8VDLBU\\SQLEXPRESS;Initial Catalog=ebookdb;Integrated Security=True";
            con.Open();
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
           
            
                cmd.CommandText = "update RegDB set cpass='" + txtcpass.Text + "' where uname='" + uname.Text + "'and cpass='"+ cpass.Text +"'" ;
                cmd.Connection = con;
               cmd.ExecuteNonQuery();
               Response.Redirect("WebForm14.aspx");
            
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            uname.Text = string.Empty;
            cpass.Text = string.Empty;
        }
    }
}