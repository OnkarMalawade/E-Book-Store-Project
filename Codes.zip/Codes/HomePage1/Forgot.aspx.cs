﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using System.Data.Sql;

namespace HomePage1
{
    public partial class WebForm4 : System.Web.UI.Page
    {

        SqlConnection con;
        SqlCommand cmd;
        protected void Page_Load(object sender, EventArgs e)
        {
            String path = "Data Source=LAPTOP-6O8VDLBU\\SQLEXPRESS;Initial Catalog=ebookdb;Integrated Security=True";
            con = new SqlConnection();
            con.ConnectionString = path;
            con.Open();
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            cmd = new SqlCommand("select cpass from RegDB where uname =@uname and umail=@umail and sec=@sec", con);
            cmd.Parameters.AddWithValue("@uname", uname.Text);
            cmd.Parameters.AddWithValue("@umail", umail.Text);
            cmd.Parameters.AddWithValue("@sec", sec.Text);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                
                Response.Redirect("WebForm17.aspx");
            }
            else
            {
                ClientScript.RegisterStartupScript(Page.GetType(), "validation", "<script language='javascript'>alert('Invalid Username and Security')</script>");
            }

            con.Close();
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            uname.Text = string.Empty;
            umail.Text = string.Empty;
            sec.Text = string.Empty;
            
        }
    }
}