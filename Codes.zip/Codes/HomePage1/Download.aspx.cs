﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using System.Data.Sql;

namespace HomePage1
{
    public partial class WebForm8 : System.Web.UI.Page
    {
         SqlCommand cmd = new SqlCommand();
        SqlConnection con = new SqlConnection();
        protected void Page_Load(object sender, EventArgs e)
        {
            GridView1.RowStyle.HorizontalAlign = HorizontalAlign.Center;
            con.ConnectionString = "Data Source=LAPTOP-6O8VDLBU\\SQLEXPRESS;Initial Catalog=ebookdb;Integrated Security=True";
            con.Open();
        }
        protected void Button2_Click(object sender, EventArgs e)
        {
            string sqlquery = "select bkname as '  Book Name  ',pdf as '  Pdf Link  ',audio as '  Audio Link  ',video as '  Video Link  ' from BookDB where bkname like '%'+@bkname+'%'";
            cmd.CommandText = sqlquery;
            cmd.Connection = con;
            cmd.Parameters.AddWithValue("bkname", bkname.Text);
            DataTable dt = new DataTable();
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            sda.Fill(dt);
            GridView1.DataSource = dt;
            GridView1.DataBind();
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
              bkname.Text = string.Empty;
        }
    }
}