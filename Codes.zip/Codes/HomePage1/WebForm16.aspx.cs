﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using System.Data.Sql;

namespace HomePage1
{
    public partial class WebForm16 : System.Web.UI.Page
    {
        SqlConnection con;
        SqlCommand cmd;
        protected void Page_Load(object sender, EventArgs e)
        {
            String path = "Data Source=LAPTOP-6O8VDLBU\\SQLEXPRESS;Initial Catalog=ebookdb;Integrated Security=True";
            con = new SqlConnection();
            con.ConnectionString = path;
            con.Open();
        }

        protected void Button1_Click(object sender, EventArgs e)
        {

            String query = " Insert into ADRegDB(ufname,ulname,umail,uname,rbt1,mob,cpass,sec)values('" + ufname.Text + "','" + ulname.Text + "','" + umail.Text + "','" + uname.Text + "','" + rbt.Text + "','" + mob.Text + "','" + cpass.Text + "','" + sec.Text + "')";
            cmd = new SqlCommand(query, con);
            cmd.ExecuteNonQuery();
            con.Close();
            Response.Redirect("AdHome.aspx");
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            ufname.Text = string.Empty;
            ulname.Text = string.Empty;
            umail.Text = string.Empty;
            uname.Text = string.Empty;
            rbt.Text = string.Empty;
            mob.Text = string.Empty;
            cpass.Text = string.Empty;
            sec.Text = string.Empty;
        }
    }
}