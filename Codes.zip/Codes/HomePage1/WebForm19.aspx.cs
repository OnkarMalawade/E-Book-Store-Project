﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using System.Data.Sql;

namespace HomePage1
{
    public partial class WebForm19 : System.Web.UI.Page
    {
        SqlConnection con;
        SqlCommand cmd;
        protected void Page_Load(object sender, EventArgs e)
        {
            String path = "Data Source=LAPTOP-6O8VDLBU\\SQLEXPRESS;Initial Catalog=ebookdb;Integrated Security=True";
            con = new SqlConnection();
            con.ConnectionString = path;
            con.Open();
        }

        protected void Button1_Click(object sender, EventArgs e)
        {

            String query = " delete from ADRegDB where uname='" + uname.Text + "' and cpass='" + cpass.Text + "'";
            cmd = new SqlCommand(query, con);
            cmd.ExecuteNonQuery();
            con.Close();
            Response.Redirect("WebForm14.aspx");
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            uname.Text = string.Empty;
            cpass.Text = string.Empty;
        }
    }
}